package com.badlogic.androidgames.uttt;

import com.badlogic.androidgames.framework.Pixmap;
import com.badlogic.androidgames.framework.Sound;

public class Assets 
{
    public static Pixmap background;
    public static Pixmap splash;
    public static Pixmap mainMenu;
    public static Pixmap buttons;
    public static Pixmap options;
    public static Pixmap help1;
    public static Pixmap help2;
    public static Pixmap help3;
    public static Pixmap credits;
    public static Pixmap ready;
    public static Pixmap pause;
    public static Pixmap gameOver1;
    public static Pixmap gameOver2;
    public static Pixmap gameOverC;
    public static Pixmap x;
    public static Pixmap o;
    public static Pixmap GSec0;
    public static Pixmap GSec1;
    public static Pixmap GSec2;
    public static Pixmap GSec3;
    public static Pixmap GSec4;
    public static Pixmap GSec5;
    public static Pixmap GSec6;
    public static Pixmap GSec7;
    public static Pixmap GSec8;
    public static Pixmap bigX;
    public static Pixmap bigO;
    public static Pixmap miniCats;
    public static Sound click;
    public static Sound clinkSound;
    //public static Sound BGM;
}
