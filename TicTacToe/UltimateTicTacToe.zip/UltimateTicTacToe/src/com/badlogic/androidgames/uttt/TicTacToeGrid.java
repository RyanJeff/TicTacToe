package com.badlogic.androidgames.uttt;

public class TicTacToeGrid 
{
	public short[] grid = new short[9];
	
	/*public boolean makeMove(int index, short move)
	{
		if(grid[index] == 0)
		{
			grid[index] = move;
			return true;
		}
		else 
		{
			return false;
		}
	}*/
	
	public void present()
    {
		
    }
}
